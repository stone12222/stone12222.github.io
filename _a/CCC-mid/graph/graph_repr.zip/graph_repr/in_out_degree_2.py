g={
    1:[4,7],
    2:[1],
    3:[4,5],
    4:[],
    5:[4],
    6:[2],
    7:[]
}

# for 3
# in-degree: how many edges which go inwards
# out-degree: how many edges which go outwards

# d={}
# for v in g.values():
#     for n in v:
#         if n not in d:
#             d[n]=1
#         else:
#             d[n]+=1
# print(d)

# d={k:0 for k in g}
# for v in g.values():
#     for n in v:
#         d[n]+=1
# print(d)
